﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinGenoration : MonoBehaviour
{
    public float timeBetweenCoins;
    private float coinGenCounter;

    public GameObject[] coinGroups;

    public Transform leftPos;
    public Transform rightPos;

    // Start is called before the first frame update
    void Start()
    {
        coinGenCounter = timeBetweenCoins;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager._canMove)

            coinGenCounter -= Time.deltaTime;

        if (coinGenCounter <= 0)
        {
            bool goLeft = Random.value > .5f;

            int chosenCoins = Random.Range(0, coinGroups.Length);
            if (goLeft)
            {
                Instantiate(coinGroups[chosenCoins], leftPos.position,transform.rotation);
            }
            else
            {
                Instantiate(coinGroups[chosenCoins], transform.position, transform.rotation);
            }

            coinGenCounter = Random.Range(timeBetweenCoins * 0.75f, timeBetweenCoins * 0.25f);
        }
        if (coinGenCounter <= 0)
        {
            bool goRight = Random.value > .5f;

            int chosenCoins = Random.Range(0, coinGroups.Length);
            if (goRight)
            {
                Instantiate(coinGroups[chosenCoins], rightPos.position, transform.rotation);
            }
            else
            {
                Instantiate(coinGroups[chosenCoins], transform.position, transform.rotation);
            }

            coinGenCounter = Random.Range(timeBetweenCoins * 0.75f, timeBetweenCoins * 0.25f);
        }

    }
}

