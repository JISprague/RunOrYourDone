﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitHazzard : MonoBehaviour
{
    public Rigidbody theRb;
    public GameManager theGM;
    public float flyAwayX;
    public float flyAwayY;
    public float flyAwayZ;
    public float enemyBoost;
    

    // Start is called before the first frame update
    void Start()
    {
        flyAwayX = Random.Range(-25,25);
        flyAwayY = Random.Range(10, 20);
        flyAwayZ = Random.Range(10, 20);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnTriggerEnter(Collider other)
    {


        if (other.tag == "Player")
        {
            Debug.Log("hitHazzard");
            theGM.HitHazard();
            theRb.isKinematic = false;
            theRb.constraints = RigidbodyConstraints.None;

            theRb.velocity = new Vector3(flyAwayX, flyAwayY, flyAwayZ);



            



        }


    }

}
