﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCollideWithPlayer : MonoBehaviour    
{
    public GameManager theGM;
    public Rigidbody theRB;
  

    public void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Debug.Log("GameOver");
            theGM.GameOver();

        }

    }
    public void ketchup()
    {
        theRB.AddForce(0,0,5f);
    }

}
