﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathGenoration : MonoBehaviour
{
    //public GameObject pathPeice;
    public GameObject[] pathPieces;
    public Transform thresholdPoint;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.z < thresholdPoint.position.z)
        {
            //copy the pathPeice and move forward//object where it goes and where its rotated
            //Instantiate(pathPeice, transform.position, transform.rotation);
            //transform.position += new Vector3(0f, 0f, 15.5f);

            //random path genoration
            int selectPiece = Random.Range(0,pathPieces.Length);
            Instantiate(pathPieces[selectPiece], transform.position, transform.rotation);
            transform.position += new Vector3(0f, 0f, 7.8f);
        }
    }
}
