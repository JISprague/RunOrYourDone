﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{
    public bool canMove;
    static public bool _canMove;
    public float worldSpeed;
    static public float _worldSpeed;
    public int coinsCollected;
    private bool gameStarted;
    public int magicPauseValue = 2;

    //speeding up
    public float timeToIncreaseSpeed;
    private float increaseSpeedCounter;
    public float speedMultiplier;
    private float targetSpeedMultiplier;
    public float acceleration;
    public float speedIncreaseAmount;
    private float worldSpeedStore;
    private float accelerationStore;

    //MENU
    public GameObject tapMessage;
    public Text coinsText;
    public Text distanceText;
    private float distanceCovered;
    public GameObject coinsMessage;
    public GameObject distanceMessage;
    public string mainMenu;
    public string retryLevel;
    public GameObject deathPannel;
    public Text deathCoins;
    public Text deathDistance;
    public float deathScreenDelay;
    public GameObject pauseScreen;
    public GameObject pauseButton;
    public Slider playerProgressSlider;
    public float enemyCatchUp = 200f;
    public float sliderMover = 150f ;
    public GameObject enemyIcon;
    public float enemySpeed;
    public float enemyIconBoost = 50;
    //getting hit 

    public int lifeCount = 5;
    public float slowDownFactor = 0.075f;
    public float slowDownLength = 2f;

    //finish stage 
    public float endStage = 1000;
    public GameObject youWinText;
    // main menu
    public Text lifeText;

    
    // Start is called before the first frame update
    void Start()
    {
        if (PlayerPrefs.HasKey("coinsCollected"))
        {
            coinsCollected = PlayerPrefs.GetInt("coinsCollected");
            
        }

        var initialLifeCount = PlayerPrefs.GetInt("lifeCount");

        if (initialLifeCount != null)
        {
            PlayerPrefs.GetInt("lifeCount");
        }
        else
        {
            PlayerPrefs.SetInt("lifeCount", lifeCount);
        }

        increaseSpeedCounter = timeToIncreaseSpeed;

        targetSpeedMultiplier = speedMultiplier;

        worldSpeedStore = worldSpeed;
        accelerationStore = acceleration;
        //menu
       // coinsText.text = "coin$:" + coinsCollected;

        distanceText.text = distanceCovered + "M";

        deathPannel.SetActive(false);
        Time.timeScale = 0f;
 

        //main menu
        lifeText.text = "lives:" + lifeCount;

    }

    // Update is called once per frame
    void Update()
    {
        _canMove = canMove;
        _worldSpeed = worldSpeed;

        if (!gameStarted && Input.GetMouseButtonDown(0))
        {
            canMove = true;
            _canMove = true;

            gameStarted = true;

            tapMessage.SetActive(false);
        }
        //increase speed over time
        if (canMove)
        {
            increaseSpeedCounter -= Time.deltaTime;
            if (increaseSpeedCounter <= 0)
            {
                increaseSpeedCounter = timeToIncreaseSpeed;
                //worldSpeed = worldSpeed * speedMultiplier;

                targetSpeedMultiplier = targetSpeedMultiplier * speedIncreaseAmount;

                timeToIncreaseSpeed = timeToIncreaseSpeed * .97f;
            }
            acceleration = accelerationStore * speedMultiplier;

            speedMultiplier = Mathf.MoveTowards(speedMultiplier, targetSpeedMultiplier, acceleration * Time.deltaTime);
            worldSpeed = worldSpeedStore * speedMultiplier;

            //updating ui
            distanceCovered += Time.deltaTime * worldSpeed;
            distanceText.text = Mathf.Floor(distanceCovered) + "M";

            Time.timeScale = 1f;
            //progress slider
            enemyProgress();
            playerProgress();
            winnerWinner();
            buyALife();
            Debug.Log(lifeCount);
        }



        // coinHitThisFrame = false;
    }

    public void GameOver()//oldHitHazzard
    {
        canMove = false;
        _canMove = false;

        PlayerPrefs.SetInt("coinsCollected", coinsCollected);

        coinsMessage.SetActive(false);
        distanceMessage.SetActive(false);
        pauseButton.SetActive(false);
        StartCoroutine("ShowDeathScreen");
        //playerProgressSlider.transform.Translate(0, -sliderMover, 0);
    }
    public IEnumerator ShowDeathScreen()
    {
        yield return new WaitForSeconds(deathScreenDelay);
        deathPannel.SetActive(true);
        deathDistance.text = Mathf.Floor(distanceCovered) + "M";
        deathCoins.text = "coin$:" + coinsCollected;
    }
    public void AddCoin()
    {
        
        coinsCollected++;//adds one coin 
                         
        coinsText.text = "coin$:" + coinsCollected;

    }
    public void Retry()
    {
        SceneManager.LoadScene(retryLevel);
        Time.timeScale = 1;
    }
    public void MainMenu()
    {
        SceneManager.LoadScene(mainMenu);
        Time.timeScale = 1;
    }
    public void ResumeGame()
    {
        pauseScreen.SetActive(false);
        Time.timeScale = 1f;
        canMove = true;
        _canMove = true;
    }
    public void PauseGame()
    {
        pauseScreen.SetActive(true);
        Time.timeScale = 0f;
        canMove = false;
        _canMove = false;
    }
    public void playerProgress()
    {
        playerProgressSlider.value = distanceCovered;
    }
    public void enemyProgress()
    {
        enemySpeed = distanceCovered * 0.0001f;
        enemyIcon.transform.Translate(enemySpeed ,0,0);
    }

    public void HitHazard()
    {
        //hit test
        //_worldSpeed -= 5;
       // Debug.Log("hit hazard");
       
        //dramatic slow down 
       
        //recover
         

        //  enemyCatchUp = enemyCatchUp + 50;
        //enemyIcon.transform.Translate(enemyIconBoost,0,0);
    }


    public void winnerWinner()
    {
        if (distanceCovered >= endStage)
        {
            youWinText.SetActive (true);
            canMove = false;
            _canMove = false;
            PlayerPrefs.SetInt("coinsCollected", coinsCollected);
            Time.timeScale = 0;
        }
    }

    public void buyALife()
    {

        if (coinsCollected >= 10)
        {
            lifeCount++;
            coinsCollected = 0;
            PlayerPrefs.SetInt("coinsCollected", coinsCollected);

        }
    }


}
