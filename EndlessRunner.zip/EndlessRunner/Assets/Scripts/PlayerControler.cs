﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControler : MonoBehaviour
{
    public GameManager theGM;
    public Rigidbody theRb;
    public GameObject[] trackPosisions;
    public Transform middle;
    public Transform left;
    public Transform right;
    public Transform player;


    // Start is called before the first frame update
    void Start()
    {
        player.position = middle.position;
        theRb.constraints = RigidbodyConstraints.FreezeAll;

    }

    // Update is called once per frame
    void Update()
    {

        if (theGM.canMove)
        {

            moveSideToSide();
        }
    }

    public void OnTriggerEnter(Collider other)
    {


        if (other.tag == "coin")
        {
            theGM.AddCoin();
            Debug.Log("hitcoin");
            Destroy(other.gameObject);
        }
    }

    public void moveSideToSide()
    {
        if (player.position == middle.position)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                theRb.constraints = RigidbodyConstraints.None;
                player.position = left.position;
                theRb.constraints = RigidbodyConstraints.FreezeAll;

            }
            if (Input.GetKeyDown(KeyCode.D))
            {
                theRb.constraints = RigidbodyConstraints.None;
                player.position = right.position;
                theRb.constraints = RigidbodyConstraints.FreezeAll;
            }
        }

        if (player.position == left.position)
        {
            
            if (Input.GetKeyDown(KeyCode.D))
            {
                theRb.constraints = RigidbodyConstraints.None;
                player.position = middle.position;
                theRb.constraints = RigidbodyConstraints.FreezeAll;
            }
        }

        if (player.position == right.position)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                theRb.constraints = RigidbodyConstraints.None;
                player.position = middle.position;
                theRb.constraints = RigidbodyConstraints.FreezeAll;
            }
            
        }

    }
}

//for player animations check out 33.29 in the endless runner cource
