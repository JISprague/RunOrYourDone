﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMovment : MonoBehaviour
{
   // public float moveSpeed;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //transform.position = transform.position - new Vector3(0, 0, moveSpeed * Time.deltaTime);

        if (GameManager._canMove)

        {
            transform.position -= new Vector3(0, 0, GameManager._worldSpeed * Time.deltaTime);
        }

        if (transform.position.z < PathDestructuionPoint.zPosition)
        {
            Destroy(gameObject);
        }
    }
}
