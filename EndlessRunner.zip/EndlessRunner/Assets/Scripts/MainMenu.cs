﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class MainMenu : GameManager
{
    public string levelToLoad;
    public Transform theCamera;
    public Transform ChrSwitchHolder;
    private Vector3 camTargetPos;
    public float cameraSpeed;
    public GameObject[] theChrs;
    public int currentChr;
    public float camSlide;
    public bool canPlay;
    public GameObject lifeCountButton;
    public GameObject playButton;
    public GameObject theGM;
    public Text lifeText;
    public int lifeCount;

    // Start is called before the first frame update
    void Start()
    {   

        camTargetPos = theCamera.position;

        if (!PlayerPrefs.HasKey(theChrs[0].name))
        {
            PlayerPrefs.SetInt(theChrs[0].name,1);
        }
        lifeCount = PlayerPrefs.GetInt("lifeCount");
        //PlayerPrefs.SetInt(theChrs[0].name, 1); might need this if default player is not unlocked
        //main menu
        lifeText.text = "lives:" + lifeCount;
    }

    // Update is called once per frame
    void Update()
    {
        theCamera.position = Vector3.Lerp(theCamera.position, camTargetPos,cameraSpeed * Time.deltaTime);
    }

    public void PlayGame()
    {
       // if (lifeCount >= 1)
        {
            SceneManager.LoadScene(levelToLoad);
        }
        
    }

    public void ChooseChar()
    {
        camTargetPos = theCamera.position + new Vector3(ChrSwitchHolder.position.x, 0f,0f);
    }
    public void moveLeft()
    {
        if (currentChr > 0)
        {
            camTargetPos -= new Vector3(camSlide, 0f, 0f);

            currentChr--;
        }
    }

    public void moveRight()
    {
        if (currentChr <= theChrs.Length - 2)
        {
            camTargetPos += new Vector3(camSlide, 0f, 0f);

            currentChr ++ ;
        }
    }

    public void unlockedCheck()
    {
        if (PlayerPrefs.HasKey(theChrs[currentChr].name))
        {
            if (PlayerPrefs.GetInt(theChrs[currentChr].name) == 0)
            {
                //61.55 might have more info on this 
            }

        }
        else
        {
            PlayerPrefs.SetInt(theChrs[currentChr].name, 0);

            unlockedCheck();
        }
    }
   // public void playWithLife()
  //  {
     //   if (PlayerPrefs.GetInt("lifeCount") <= 0)
   //     {
            
        
    //        playButton.SetActive(false);

    //    }
   // }
    public void showLives()
    {
        lifeText.text = "lives:" + lifeCount;
    }
}
