﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContinueGame : MonoBehaviour
{
    private Vector3 startPosision;
    private Quaternion startRotation;
    public PlayerControler thePlayer;
    public float invisableTime;
    private float invensableTimer;

    // Start is called before the first frame update
    void Start()
    {
        startPosision = transform.position;
        startRotation = transform.rotation;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void cointinueGame()
    {
       // if (coinsCollected >= 100)
        {
            //55.48
            //coinsCollected-=100;
            //canMove = true;
            //_canMove = true;
           // thePlayer.resetPlayer();
        }
    }
    public void resetPlayer()
    {
        // theRB.constraints = RigidbodyConstraints.FreezeRotation;
        transform.position = startPosision;
        transform.rotation = startRotation;
        invensableTimer = invisableTime;
    }
    //controle invinsability
   // if (invensableTimer <= 0)
       // {
        //hazzard scripts
       // }
}
